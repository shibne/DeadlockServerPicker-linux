"""
Tests for Deadlock Server Picker.
"""
